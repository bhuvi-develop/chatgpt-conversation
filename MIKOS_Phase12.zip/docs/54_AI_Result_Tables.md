# AI Result Tables

Prediction, anomaly, OEE and health tables.

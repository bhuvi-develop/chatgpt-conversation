# PostgreSQL Asset Tables

Asset master, manufacturers, models, locations.

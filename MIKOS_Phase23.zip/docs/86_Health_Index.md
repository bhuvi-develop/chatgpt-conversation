# Asset Health Index

Enterprise health scoring.
# Feature Engineering

Shared feature computation pipeline.
# API Adapters

Adapter layer for external services.
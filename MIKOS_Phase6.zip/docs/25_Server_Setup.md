# Server Setup

FastAPI, PostgreSQL, WebSocket, reverse proxy, environment configuration.
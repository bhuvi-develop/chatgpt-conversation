# MIKOS Phase6

This phase contains enterprise documentation chapters.

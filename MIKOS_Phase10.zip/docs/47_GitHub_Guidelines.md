# GitHub Guidelines

Repository structure, branching and documentation standards.
# Roadmap V2

Expansion to additional assets and advanced analytics.
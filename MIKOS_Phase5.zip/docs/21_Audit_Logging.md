# Audit Logging

System audit trail, user activity, configuration changes, telemetry access history.
# Backup & Recovery

Database backup strategy, recovery objectives, disaster recovery planning.
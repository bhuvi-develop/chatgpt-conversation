# Anomaly Injection

Inject thermal rise, over-voltage, cable faults and charging interruptions.
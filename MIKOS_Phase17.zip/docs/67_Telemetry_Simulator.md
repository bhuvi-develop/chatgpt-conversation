# Telemetry Simulator

Enterprise simulator for laptop and mobile chargers with realistic voltage, current, power and temperature fluctuations.
# WebSocket Architecture

Store-before-stream, live updates every second, asset filtering, scalable channels.

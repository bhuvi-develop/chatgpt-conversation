# Data Pipeline

Mock + Sensor + Simulator + Free APIs -> Normalize -> Validate -> PostgreSQL -> AI -> WebSocket.

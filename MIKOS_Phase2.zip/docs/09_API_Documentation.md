# API Documentation

REST endpoints for assets, telemetry, anomalies, predictive maintenance, APM and OEE.

# Backend Architecture

FastAPI backend, PostgreSQL, WebSocket, unified telemetry pipeline, service layer, repository layer, controllers, AI engine integration.

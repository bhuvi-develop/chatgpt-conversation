# PostgreSQL Design

Tables: asset_master, telemetry, anomaly_events, predictive_results, maintenance_history, oee_metrics, alerts, sessions.

# KPI Catalog

Enterprise KPIs for AD, PdM, APM and OEE.
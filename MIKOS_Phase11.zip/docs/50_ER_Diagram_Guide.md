# ER Diagram Guide

Entity relationships, keys, normalization strategy.

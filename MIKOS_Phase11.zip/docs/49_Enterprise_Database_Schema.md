# Enterprise Database Schema

Detailed documentation for asset registry, telemetry, AI results, maintenance, OEE and relationships.

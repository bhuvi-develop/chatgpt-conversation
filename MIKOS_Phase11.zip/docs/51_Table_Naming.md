# Table Naming Standards

Naming conventions, indexes and constraints.

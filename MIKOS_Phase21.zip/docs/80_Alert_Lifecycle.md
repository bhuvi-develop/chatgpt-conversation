# Alert Lifecycle

Creation, acknowledgement and closure.
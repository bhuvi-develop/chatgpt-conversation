# KPI Definitions

Fleet KPI documentation.
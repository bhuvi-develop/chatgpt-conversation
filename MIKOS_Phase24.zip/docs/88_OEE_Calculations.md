# OEE Calculations

Availability, Performance and Quality.
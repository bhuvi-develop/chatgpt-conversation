# Dashboard Architecture

Single-page enterprise command center.

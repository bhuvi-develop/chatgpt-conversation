# Insight Drawer

Right-side reusable contextual drawer for KPI cards, charts and assets.

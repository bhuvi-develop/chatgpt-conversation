# Enterprise UI/UX

Insight Drawer, blur background, responsive interactions.

# Insight Drawer

Single-page drill-down UX.
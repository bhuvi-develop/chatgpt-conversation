# Dashboard Modules

AD, PdM, APM and OEE widgets.
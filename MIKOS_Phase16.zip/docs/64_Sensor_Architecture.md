# Sensor Architecture

ESP32, MQTT, Modbus and HTTP adapter architecture.

# Sensor Adapters

Abstraction layer and interfaces.

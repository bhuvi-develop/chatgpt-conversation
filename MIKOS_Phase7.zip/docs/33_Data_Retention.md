# Data Retention

Historical telemetry retention and archival strategy.
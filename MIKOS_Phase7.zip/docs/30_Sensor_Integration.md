# Sensor Integration

ESP32, MQTT, Modbus, HTTP adapters and normalization.
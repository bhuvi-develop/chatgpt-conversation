# Simulator Engine

Live telemetry simulation, anomaly injection and scenario generation.
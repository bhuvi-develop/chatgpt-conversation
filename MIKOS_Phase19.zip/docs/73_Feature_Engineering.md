# Feature Engineering

Shared feature computation for all AI modules.
# Data Preprocessing

Cleaning, normalization and aggregation.
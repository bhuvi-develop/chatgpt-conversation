# System Architecture

## High-Level Flow

Mock Data
+
Sensor Data
+
Simulator
+
Free APIs
        |
        v
Data Ingestion
        |
Normalization
        |
Validation
        |
PostgreSQL
        |
AI Engine
 |-- Anomaly Detection
 |-- Predictive Maintenance
 |-- Asset Performance
 |-- OEE
        |
REST API + WebSocket
        |
Dashboard

## Design Principles
- Backend is the single source of truth.
- Store before stream.
- Frontend is visualization only.

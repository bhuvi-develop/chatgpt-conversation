# Project Overview

## Vision
Build one enterprise platform instead of multiple disconnected maintenance tools.

## Objectives
- One telemetry pipeline
- Shared feature engineering
- Reusable AI modules
- Enterprise dashboard

## Core Modules
1. Anomaly Detection
2. Predictive Maintenance
3. Asset Performance Management
4. OEE

## Data Flow
Telemetry -> Feature Engineering -> AI -> PostgreSQL -> APIs/WebSocket -> Dashboard

## Version 1 Scope
Only Laptop Chargers and Mobile Chargers are implemented.
Future assets can reuse the same architecture.

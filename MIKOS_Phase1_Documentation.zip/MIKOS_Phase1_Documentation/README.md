# MIKOS Enterprise AIoT Platform

## Overview
MIKOS is a unified AIoT platform designed around a single telemetry pipeline that powers:
- Anomaly Detection
- Predictive Maintenance
- Asset Performance Management
- Overall Equipment Effectiveness (OEE)

## Version 1
Supported assets:
- Laptop Chargers
- Mobile Chargers

## Repository Structure
See the `docs/` folder for detailed architecture and business documentation.

## Technology
- Backend: FastAPI
- Database: PostgreSQL
- Streaming: WebSocket
- Data Sources: Mock + Sensor + Simulator + Free APIs
